package com.ybkj.cnooc.common.util;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * <p>
 * 类描述：响应给浏览器
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/22 13:51
 */
public class R<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final int NO_LOGIN = -1;

    public static final int SUCCESS = 0;

    public static final int FAIL = 1;

    public static final int NO_PERMISSION = 2;

    @Getter
    @Setter
    private String msg = "success";
    @Getter
    @Setter
    private int code = SUCCESS;
    @Getter
    @Setter
    private T data;

    public R(){
        super();
    }
    
    public R(T data) {
        super();
        this.data = data;
    }

    public R(T data, String msg) {
        super();
        this.data = data;
        this.msg = msg;
    }

    public R(Throwable e) {
        super();
        this.msg = e.getMessage();
        this.code = FAIL;
    }

}
