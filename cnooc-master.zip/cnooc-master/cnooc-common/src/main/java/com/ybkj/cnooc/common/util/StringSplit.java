package com.ybkj.cnooc.common.util;

import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * 类描述：字符串截取
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/25 17:23
 */
@Slf4j
public class StringSplit {
    /**
     * @Description:  功能描述（分割已，分割的字符串）
     * @Author:       刘家义
     * @CreateDate:   2018/11/5 10:27
     */
    public static String[] slicerComma(String s){
        String[] result=s.split(",");
        log.debug("分割 “,” =result="+result);
        return result;
    }
}
