package com.ybkj.cnooc.common.util.exception;

public class UserException extends RuntimeException{

    private static final long serialVersionUID = 1L;
    private Integer code;

    public UserException(){
        super();
    }
    public UserException(String msg,Integer errorCode){
        super(msg);
        code=errorCode;
    }
    public Integer getCode() {
        return code;
    }


}
