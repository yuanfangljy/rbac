package com.ybkj.cnooc.common.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


@Data
public class RoleVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<String> roles;
}
