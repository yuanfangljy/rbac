package com.ybkj.cnooc.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * <p>
 * 类描述：
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/19 19:06
 */
@EnableEurekaServer
@SpringBootApplication
public class CnoocEurekaApplication {
    public static void main(String[] args) {
        SpringApplication.run(CnoocEurekaApplication.class, args);
    }
}




