package com.ybkj.cnooc.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

/**
 * <p>
 * 类描述：权限管理
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/19 19:00
 */
/*@EnableTransactionManagement
@EnableAsync*/
@EnableEurekaClient
@SpringBootApplication
public class CnoocAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(CnoocAdminApplication.class, args);
    }
}
