package com.ybkj.cnooc.admin.common.security;

import com.ybkj.cnooc.common.constant.ResponseConstant;
import com.ybkj.cnooc.common.util.R;
import com.ybkj.cnooc.common.util.exception.CheckedException;
import com.ybkj.cnooc.common.util.exception.UserException;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.connector.Response;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * <p>
 * 类描述：认证失败
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/22 13:14
 */

@Component
@Slf4j
public class MyAuthenticationFailureHandler implements AuthenticationFailureHandler {
    @Override
    public void onAuthenticationFailure(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException e) throws IOException, ServletException {
        responseBrowser(e,httpServletResponse);
    }

    public R<String> responseBrowser(AuthenticationException e,HttpServletResponse response) throws IOException {
        R<String> r = new R<>();
        r.setCode(R.FAIL);
        if (e instanceof UsernameNotFoundException || e instanceof BadCredentialsException) {
            log.error("用户名或密码输入错误，登录失败!");
            response.setStatus(ResponseConstant.SC_BAD_REQUEST);
            //throw new CheckedException("用户名或密码输入错误，登录失败!");
        } else if (e instanceof DisabledException) {
            log.error("账户被禁用，登录失败，请联系管理员!");
            response.setStatus(ResponseConstant.SC_FORBIDDEN_FAIL);
        } else if (e instanceof LockedException) {
            log.error("用户被锁定，登录失败，请联系管理员!");
            response.setStatus(ResponseConstant.SC_LOCKED_IN_FAIL);
        } else {
            log.error("登录失败!");
        }
        //System.out.println(r.getCode()+"---"+r.getMsg()+"---"+r.getData());
        return r;
    }
}
