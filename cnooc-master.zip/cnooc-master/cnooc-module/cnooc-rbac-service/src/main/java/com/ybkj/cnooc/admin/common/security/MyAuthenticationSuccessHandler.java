package com.ybkj.cnooc.admin.common.security;

import com.ybkj.cnooc.common.constant.ResponseConstant;
import com.ybkj.cnooc.common.util.AuthUtils;
import com.ybkj.cnooc.common.util.exception.CheckedException;
import com.ybkj.cnooc.common.util.exception.UserException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/*
 * <p>
 * 类描述：认证成功
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/22 13:15
 */

@Slf4j
@Component
public class MyAuthenticationSuccessHandler implements AuthenticationSuccessHandler{

    public static final String BASIC_ = "Basic ";

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        String header = request.getHeader("Authorization");
        System.out.println("请求头中的信息："+header);
        if (header == null || !header.startsWith(BASIC_)) {
            log.error("请求头中client信息为空");
            response.setStatus(ResponseConstant.SC_PAYMENT_REQUIRED);
            //throw new CheckedException("请求头中client信息为空");
        }
        //response.setStatus(HttpServletResponse.SC_ACCEPTED);
        log.info("认证成功--debug");
        /*String[] tokens = AuthUtils.extractAndDecodeHeader(header);
        assert tokens.length == 2;
        String clientId = tokens[0];

        System.out.println("000---------------"+clientId);*/
    }
}
