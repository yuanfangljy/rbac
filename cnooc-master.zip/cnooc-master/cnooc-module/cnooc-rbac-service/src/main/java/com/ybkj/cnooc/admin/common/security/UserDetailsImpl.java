package com.ybkj.cnooc.admin.common.security;

import com.ybkj.cnooc.admin.model.SysUser;
import com.ybkj.cnooc.common.constant.CommonConstant;
import com.ybkj.cnooc.common.constant.SecurityConstants;
import com.ybkj.cnooc.common.vo.PermissionVO;
import com.ybkj.cnooc.common.vo.SysRole;
import com.ybkj.cnooc.common.vo.UserVO;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/*
 * <p>
 * 类描述：
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/21 16:48
 */

//@Service
public class UserDetailsImpl implements UserDetails {


    @Getter
    @Setter
    private Integer userId;
    @Getter
    @Setter
    private String username;
    @Getter
    @Setter
    private String password;
    @Getter
    @Setter
    private String status;
    @Getter
    @Setter
    private List<PermissionVO> permissionVOList;
    @Getter
    @Setter
    private List<SysRole> roleList;

    public UserDetailsImpl(UserVO userVo/*, List<PermissionVO> permissionVO*/){
        this.userId=userVo.getUserId();
        this.username = userVo.getUserName();
        this.password = userVo.getPassword();
        this.status = userVo.getDelFlag();
        //this.permissionVOList=permissionVO;
        this.roleList = userVo.getRoleList();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> authorityList = new ArrayList<>();
        // 根据用户查询用户对应权限,树状结构
        for (SysRole permission : roleList) {
            System.out.println("权限----"+permission.toString());
                authorityList.add(new SimpleGrantedAuthority(permission.getRoleCode()));
        }
        authorityList.add(new SimpleGrantedAuthority(SecurityConstants.BASE_ROLE));
        return authorityList;
    }

    /**
     * 数据库中密码
     * @return
     */
    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    //判断帐号是否已经过期
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    //锁定用户  9
    @Override
    public boolean isAccountNonLocked() {
        return !StringUtils.equals(CommonConstant.STATUS_LOCK, status);
    }

    //判断用户凭证是否已经过期
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    //正常用户  1
    @Override
    public boolean isEnabled() {
        return StringUtils.equals(CommonConstant.STATUS_NORMAL, status);
    }
}
