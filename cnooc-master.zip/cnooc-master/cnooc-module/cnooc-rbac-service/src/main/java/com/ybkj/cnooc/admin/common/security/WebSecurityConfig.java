package com.ybkj.cnooc.admin.common.security;

import com.ybkj.cnooc.admin.mapper.SysMenuMapper;
import com.ybkj.cnooc.admin.model.SysMenu;
import com.ybkj.cnooc.admin.service.impl.SysUserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import java.util.List;

//
//import com.mayikt.handler.MyAuthenticationFailureHandler;
//import com.mayikt.handler.MyAuthenticationSuccessHandler;


// Security 配置
@Component
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private SysUserServiceImpl sysUserService;
    @Autowired
    private SysMenuMapper sysMenuMapper;
    @Autowired
    private MyAuthenticationFailureHandler failureHandler;
    @Autowired
    private MyAuthenticationSuccessHandler successHandler;
    @Autowired
    UrlFilterInvocationSecurityMetadataSource urlFilterInvocationSecurityMetadataSource;
    @Autowired
    UrlAccessDecisionManager urlAccessDecisionManager;

    // 配置认证用户信息和权限
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //动态配置用户信息进行加密认证
        auth.userDetailsService(sysUserService).passwordEncoder(new BCryptPasswordEncoder(){
            public boolean matches(CharSequence rawPassword, String encodedPassword) {
              /* encodedPassword.equals()*/
                System.out.println(rawPassword+"----"+encodedPassword);
                return true;
            }

           /* public String encode(CharSequence rawPassword) {
                System.out.println(rawPassword+"----");
                return null;
            }*/
        });

    }


    /*@Bean
    public AccessDecisionManager accessDecisionManager() {
        return new UrlAccessDecisionManager();
    }
    @Bean
    public FilterInvocationSecurityMetadataSource securityMetadataSource() {
        return new UrlFilterInvocationSecurityMetadataSource();
    }*/

    // 配置拦截请求资源
    protected void configure(HttpSecurity http) throws Exception {
        // // 如何权限控制 给每一个请求路径 分配一个权限名称 让后账号只要关联该名称，就可以有访问权限
       /*     http
                .authorizeRequests()//拦截请求，创建FilterSecurityInterceptor
                .antMatchers("/**")//拦截所有的请求
                //.antMatchers("/**")//拦截所有的请求
                .fullyAuthenticated()//安全模式
                .and().formLogin()//认证模式（登录）
                .loginPage("/login_c")//自定义登录页面(请求路径)
                .and().csrf().disable();//默认开启，可以显示关闭(否则登录要带csrfToken)*/
        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry registry =
                http
                      .formLogin()/*.loginPage("/sysUser/login")*/
                      .loginProcessingUrl("/sysUser/login")
                      .successHandler(successHandler).failureHandler(failureHandler)
                      .and()
                      .authorizeRequests()
                      .withObjectPostProcessor(new ObjectPostProcessor<FilterSecurityInterceptor>() {
                          public <O extends FilterSecurityInterceptor> O postProcess(O fsi) {
                              fsi.setAccessDecisionManager(urlAccessDecisionManager);
                              fsi.setSecurityMetadataSource(urlFilterInvocationSecurityMetadataSource);
                              return fsi;
                          }
                      });

                /*sysMenuMapper.selectList(null).forEach(url -> registry.antMatchers(url.getUrl()).hasAuthority(url.getUrl()));*/
                registry.antMatchers("/sysUser/login").permitAll()
                        .anyRequest().authenticated()//任何请求,登录后可以访问
                        .and()
                        .logout().permitAll()//注销行为任意访问
                        .and()
                        .csrf().disable();


/*

        List<SysMenu> listPermission = sysMenuMapper.selectList(null);

        for (SysMenu permission : listPermission) {
            registry.antMatchers(permission.getUrl()).hasAnyAuthority(permission.getPermission());
        }
        registry.antMatchers("/sysUser/login").permitAll()
                .antMatchers("/**").fullyAuthenticated()
                .and()
                .formLogin()*/
/*.loginPage("/sysUser/login")*//*

                .and()
                .csrf().disable();
*/

        /*List<SysMenu> listPermission = sysMenuMapper.selectList(null);
        ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authorizeRequests = http
                .authorizeRequests();
        for (SysMenu permission : listPermission) {
            authorizeRequests.antMatchers(permission.getUrl()).hasAnyAuthority(permission.getPath());
        }
        authorizeRequests.antMatchers("/login").permitAll().antMatchers("/**").fullyAuthenticated().and().formLogin().loginPage("/login")
               .and().csrf().disable();*/

    }


}
