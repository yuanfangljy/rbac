package com.ybkj.cnooc.admin.common.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * <p>
 * 类描述：
 * </p>
 *
 * @author liujiayi
 * @version：1.0
 * @since 2018/12/21 17:13
 */
public class Encrypted {
    private static final PasswordEncoder ENCODER = new BCryptPasswordEncoder();

    public static String getPassword(String password){
        String encodePassword = ENCODER.encode(password);
        System.out.println("your password..."+encodePassword);
        return encodePassword;
    }

    public static void main(String[] args) {
        Encrypted.getPassword("123456");
    }
}
