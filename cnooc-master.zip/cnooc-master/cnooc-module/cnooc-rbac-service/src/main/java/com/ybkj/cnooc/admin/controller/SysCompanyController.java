package com.ybkj.cnooc.admin.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ybkj.cnooc.admin.model.SysCompany;
import com.ybkj.cnooc.admin.model.SysRole;
import com.ybkj.cnooc.admin.service.ISysCompanyService;
import com.ybkj.cnooc.common.constant.CommonConstant;
import com.ybkj.cnooc.common.util.QueryPar;
import com.ybkj.cnooc.common.util.R;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import java.util.Map;

/**
 * <p>
 *  前端控制器: 公司
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Api(value = "/",description = "公司管理")
@RestController
@RequestMapping("/sysCompany")
public class SysCompanyController {

    @Autowired
    private ISysCompanyService companyService;


    /**
     * 分页查询角色信息
     * @param params 分页对象
     * @return       分页对象
     */
    @GetMapping("/companyPage")
    public IPage companyPage(@RequestParam Map<Object, Object> params){
        IPage<SysCompany> userIPage = companyService.page(new QueryPar<>(params), new QueryWrapper<SysCompany>().like("name",params.get("companyName")));
        return userIPage;
    }


    /**
     * 根据公司Id,查询公司信息
     * @param cId 公司Id
     * @return 公司信息
     */
    @GetMapping("/selectCompanyById/{cId}")
    public SysCompany selectCompanyById(@PathVariable Integer cId){
        return companyService.getById(cId);
    }

    /**
     * 新增公司
     * @param company
     * @return success/fail
     */
    @PostMapping("/addCompany")
    public R<Boolean> addCompany(@RequestBody SysCompany company){
        return new R<>(companyService.save(company));
    }


    /**
     * 删除公司
     * @param cId  公司Id
     * @return success/fail
     */
    @DeleteMapping("/delCompany/{cId}")
    public R<Boolean> delCompany(@PathVariable Integer cId){
        SysCompany company=companyService.getById(cId);
        company.setDelFlag(CommonConstant.STATUS_DEL);
        return new R<>(companyService.updateById(company));
    }

    /**
     * 更新公司
     * @param company 公司信息
     * @return success/fail
     */
    @PutMapping("/updateCompany")
    public R<Boolean> updateCompany(@RequestBody SysCompany company){
        return new R<>(companyService.updateById(company));
    }
}

