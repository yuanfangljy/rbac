package com.ybkj.cnooc.admin.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.ybkj.cnooc.admin.model.SysDict;
import com.ybkj.cnooc.admin.service.impl.SysDictServiceImpl;
import com.ybkj.cnooc.common.constant.CommonConstant;
import com.ybkj.cnooc.common.util.QueryPar;
import com.ybkj.cnooc.common.util.R;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器:字典
 * </p>
 *
 * @author liujiayi
 * @since 2019-01-23
 */
@Api(value = "/",description = "字典管理")
@RestController
@RequestMapping("/sysDict")
public class SysDictController {

    @Autowired
    private SysDictServiceImpl sysDictService;

    /**
     * 分页查询字典信息
     *
     * @param params 分页对象
     * @return 分页对象
     */
    @GetMapping("/dictPage")
    public IPage dictPage(@RequestParam Map<Object, Object> params) {
        //params.put(CommonConstant.DEL_FLAG, CommonConstant.STATUS_NORMAL);
        IPage<SysDict> dictIPage = sysDictService.page(new QueryPar<>(params),new QueryWrapper<SysDict>().like("type",params.get("type")));
        return dictIPage;
    }
    private <T> void print(List<T> list) {
        if (!CollectionUtils.isEmpty(list)) {
            list.forEach(System.out::println);
        }
    }


    /**
     * 根据数据值和类型来获取对应的标签名
     * @param value 数值
     * @param type  类型
     * @return
     */
    @GetMapping("/getLabel")
    public String getLabel(@RequestParam(value = "value")String value,@RequestParam(value = "type")String type){
        String label = sysDictService.getLabel(value, type);
        System.out.println(label);
        return  label;
    }


    /**
     * 通过字典类型查找字典
     *
     * @param type 类型
     * @return 同类型字典
     */
    @GetMapping("/type/{type}")
   // @Cacheable(value = "dict_details", key = "#type")
    public List<SysDict> findDictByType(@PathVariable String type) {
        SysDict condition = new SysDict();
        condition.setDelFlag(CommonConstant.STATUS_NORMAL);
        condition.setType(type);
        return sysDictService.list(new QueryWrapper<>(condition));
    }


    /**
     * 添加字典
     *
     * @param sysDict 字典信息
     * @return success、false
     */
    @PostMapping(value = "/addDict")
    @CacheEvict(value = "dict_details", key = "#sysDict.type")
    public R<Boolean> addDict(@RequestBody SysDict sysDict) {
        return new R<>(sysDictService.save(sysDict));
    }

    /**
     * 删除字典，并且清除字典缓存
     *
     * @param id   ID
     * @param type 类型
     * @return R
     */
    @DeleteMapping("/delDict/{id}/{type}")
    @CacheEvict(value = "dict_details", key = "#type")
    public R<Boolean> deleteDict(@PathVariable Integer id, @PathVariable String type) {
        return new R<>(sysDictService.removeById(id));
    }

    /**
     * 修改字典
     *
     * @param sysDict 字典信息
     * @return success/false
     */
    @PutMapping("/updateDict")
    @CacheEvict(value = "dict_details", key = "#sysDict.type")
    public R<Boolean> editDict(@RequestBody SysDict sysDict) {
        return new R<>(sysDictService.updateById(sysDict));
    }
}

