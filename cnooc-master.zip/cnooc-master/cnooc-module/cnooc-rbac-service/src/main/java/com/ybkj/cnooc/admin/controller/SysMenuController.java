package com.ybkj.cnooc.admin.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ybkj.cnooc.admin.common.util.TreeUtil;
import com.ybkj.cnooc.admin.mapper.SysUserMapper;
import com.ybkj.cnooc.admin.model.SysMenu;
import com.ybkj.cnooc.admin.service.ISysUserService;
import com.ybkj.cnooc.common.vo.SysRole;
import com.ybkj.cnooc.admin.model.dto.MenuTree;
import com.ybkj.cnooc.admin.service.ISysMenuService;
import com.ybkj.cnooc.common.constant.CommonConstant;
import com.ybkj.cnooc.common.util.R;
import com.ybkj.cnooc.common.vo.MenuVO;
import com.ybkj.cnooc.common.vo.UserVO;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;


import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 *  前端控制器: 菜单
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Api(value = "/",description = "菜单管理")
@RestController
@RequestMapping("/sysMenu")
public class SysMenuController {

    @Autowired
    private ISysMenuService sysMenuService;
    @Autowired
    private SysUserMapper userMapper;

    /**
     * 通过角色编码查询用户菜单
     *
     * @param roleCode 角色编码
     * @return 菜单列表
     */
    @GetMapping("/selectMenuByRole/{roleCode}")
    public List<MenuVO> selectMenuByRole(@PathVariable String roleCode) {
        return sysMenuService.findMenuByRoleCode(roleCode);
    }

    /**
     * 通过菜单Id,查询菜单信息
     * @param menuId 菜单Id
     * @return 菜单对象
     */
    @GetMapping("/{menuId}")
    public SysMenu getMenu(@PathVariable Integer menuId){
        return sysMenuService.getById(menuId);
    }

    /**
     * 返回当前用户的树形菜单集合
     * @param userName
     * @return当前用户的树形菜单
     */
    @GetMapping(value = "/userMenu")
    public List<MenuTree> userMenu(){
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication() .getPrincipal();
        UserVO userVO = userMapper.selectUserVoByUserName(userDetails.getUsername());
      /*  List<SysRole> sysRole1=new ArrayList<>();
        SysRole sysRole=new SysRole();
        sysRole.setDelFlag("1");
        sysRole.setRoleCode("super");
        sysRole.setRoleDesc("超级管理");
        sysRole.setRoleId(1);
        sysRole1.add(sysRole);
        userVO.setRoleList(sysRole1);*/
        // 获取符合条件得菜单,且不重复
        Set<MenuVO> all=new HashSet<>();
        userVO.getRoleList().forEach(role->all.addAll(sysMenuService.findMenuByRoleCode(role.getRoleCode())));
        List<MenuTree> menuTreeList=all.stream().filter(vo-> CommonConstant.MENU
                .equals(vo.getType()))
                .map(MenuTree::new)
                .sorted(Comparator.comparingInt(MenuTree::getSort))
                .collect(Collectors.toList());
        List<MenuTree> bulid = TreeUtil.bulid(menuTreeList, 0);
        bulid.forEach(System.out::println);
        return bulid;
    }

    /**
     * 新增菜单
     * @param sysMenu
     * @return success/fail
     */
    @PostMapping("/addMenu")
    public R<Boolean> addMenu(@RequestBody SysMenu sysMenu){
        return new R<>(sysMenuService.save(sysMenu));
    }

    /**
     * 删除菜单
     * @param menuId
     * @return success/fail
     * TODO   级联删除子菜单
     */
    @DeleteMapping("/delMenu/{menuId}")
    public R<Boolean> delMenu(@PathVariable Integer menuId){
        return new R<>(sysMenuService.removeMenuByMenuId(menuId));
    }

    /**
     * 更新菜单
     * @param sysMenu
     * @return success/fail
     */
    @PutMapping("/updateMenu")
    public R<Boolean> updateMenu(@RequestBody SysMenu sysMenu){
        return new R<>(sysMenuService.updateById(sysMenu));
    }

    /**
     * 返回角色的菜单集合
     *
     * @param roleCode 角色标识
     * @return
     */
    @GetMapping("/getRoleTree/{roleCode}")
    public List<Integer> getRoleTree(@PathVariable String roleCode){
        List<MenuVO> menus = sysMenuService.findMenuByRoleCode(roleCode);
        List<Integer> menuList= new ArrayList<>();
        for (MenuVO menuVo : menus) {
            menuList.add(menuVo.getMenuId());
        }
        return menuList;
    }

    /**
     * 返回树形菜单集合
     *
     * @return 树形菜单
     */
    @GetMapping(value = "/allTree")
    public List<MenuTree> getTree() {
        SysMenu condition = new SysMenu();
        condition.setDelFlag(CommonConstant.STATUS_NORMAL);
        return TreeUtil.bulidTree(sysMenuService.list(new QueryWrapper<>(condition)), 0);
    }
}

