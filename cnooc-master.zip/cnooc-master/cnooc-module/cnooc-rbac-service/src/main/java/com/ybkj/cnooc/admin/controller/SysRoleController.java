package com.ybkj.cnooc.admin.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ybkj.cnooc.admin.model.SysRole;
import com.ybkj.cnooc.admin.model.SysUser;
import com.ybkj.cnooc.admin.service.ISysRoleMenuService;
import com.ybkj.cnooc.admin.service.ISysRoleService;
import com.ybkj.cnooc.common.constant.CommonConstant;
import com.ybkj.cnooc.common.util.Query;
import com.ybkj.cnooc.common.util.QueryPar;
import com.ybkj.cnooc.common.util.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.Map;

/**
 * <p>
 *  前端控制器:角色
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Api(value = "/",description = "角色管理")
@RestController
@RequestMapping("/sysRole")
public class SysRoleController {

    @Autowired
    private ISysRoleService sysRoleService;
    @Autowired
    private ISysRoleMenuService sysRoleMenuService;


    /**
     * 通过角色ID查询角色信息
     * @param roleId  角色Id
     * @return 角色信息
     */
    @GetMapping("/{roleId}")
    public SysRole selectRole(@PathVariable Integer roleId){
        return sysRoleService.getById(roleId);
    }

    /**
     * 分页查询角色信息
     * @param params 分页对象
     * @return       分页对象
     */
    @GetMapping("/rolePage")
    public IPage rolePage(@RequestParam Map<Object, Object> params){
        IPage<SysRole> userIPage = sysRoleService.page(new QueryPar<>(params), new QueryWrapper<SysRole>().like("role_name",params.get("roleName")));
        return userIPage;
    }

    /**
     * 新增角色
     * @param sysRole 角色信息
     * @return success/fail
     */
    @PostMapping("/addRole")
    public R<Boolean> addRole(@RequestBody SysRole sysRole){
        return new R<>(sysRoleService.save(sysRole));
    }

    /**
     * 删除角色
     * @param roleId 角色Id
     * @return success/fail
     */
    @DeleteMapping("/delRole/{roleId}")
    public R<Boolean> delRole(@PathVariable Integer roleId){
        SysRole sysRole=sysRoleService.getById(roleId);
        sysRole.setDelFlag(CommonConstant.STATUS_DEL);
        return new R<>(sysRoleService.updateById(sysRole));
    }

    /**
     * 修改角色
     * @param sysRole 角色信息
     * @return success/fail
     */
    @PutMapping("/updateRole")
    public R<Boolean> updateRole(@RequestBody SysRole sysRole){
        return new R<>(sysRoleService.updateById(sysRole));
    }

    /**
     * 更新角色：菜单
     * @param roleId  角色Id
     * @param menuIds 菜单Id结合
     * @return success/fail
     */
    @PutMapping("/updateRoleTree")
    public R<Boolean> updateRoleTree(@RequestParam(value = "roleId",required = false)Integer roleId,@RequestParam(value = "menuIds",required = false)String menuIds){
        System.out.println(roleId+"-------"+menuIds);
        //查询角色相关信息，得到角色Code,从缓存中读取
        SysRole sysRole = sysRoleService.getById(roleId);
        return new R<>(sysRoleMenuService.insertRoleMenus(sysRole.getRoleCode(), roleId, menuIds));
    }



}

