package com.ybkj.cnooc.admin.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * qwerqwer 前端控制器
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-21
 */
@Controller
@RequestMapping("/sysRoleMenu")
public class SysRoleMenuController {

}

