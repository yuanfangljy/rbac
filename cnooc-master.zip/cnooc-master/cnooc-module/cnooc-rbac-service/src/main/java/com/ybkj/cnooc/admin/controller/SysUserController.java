package com.ybkj.cnooc.admin.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.ybkj.cnooc.admin.mapper.SysUserMapper;
import com.ybkj.cnooc.admin.model.SysUser;
import com.ybkj.cnooc.admin.model.SysUserRole;
import com.ybkj.cnooc.admin.model.dto.UserDTO;
import com.ybkj.cnooc.admin.model.dto.UserInfo;
import com.ybkj.cnooc.admin.service.ISysUserRoleService;
import com.ybkj.cnooc.admin.service.ISysUserService;
import com.ybkj.cnooc.common.util.Query;
import com.ybkj.cnooc.common.util.R;
import com.ybkj.cnooc.common.vo.UserVO;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Slf4j
@Api(value = "/",description = "用户管理")
@RestController
@RequestMapping("/sysUser")
public class SysUserController  {

    //密码加密
    private static final PasswordEncoder ENCODER = new BCryptPasswordEncoder();

    @Autowired
    private ISysUserService userService;
    @Autowired
    private ISysUserRoleService userRoleService;


    @Autowired
    private SysUserMapper userMapper;

    @PostMapping("/login")
    public void login(){
        log.debug("---666---进入到登录访问------");
    }


    /**
     * 根据用户Id,查询用户信息
     * @param userId 用户Id
     * @return UserVo
     */
    @GetMapping("/selectUserById/{userId}")
    public UserVO selectUserById(@PathVariable Integer userId){
        return userService.getUserById(userId);
    }

    /**
     * 用户分页查询:用户名
     * @param params 参数集合
     * @return 用户集合
     */
   /* @ApiImplicitParam(name = "params" , paramType = "body",examples = @Example({
            @ExampleProperty(value = "{'size':2}", mediaType = "application/json")
    }))*/
   // @ApiImplicitParam(name="userName",value="用户名",dataType="String", paramType = "query")
    @GetMapping("/userPage")
    public IPage userPage(@RequestParam Map<Object,Object> params){

       /* Map<String,Object> parm=new HashMap<>();
        parm.put("size",5);*/
        //new QueryWrapper<SysUser>().lambda().select(SysUser::getUserName) 只查用户名
        IPage userIPage=userService.selectWithRolePage(new Query<>(params));
        /*IPage<SysUser> userIPage = userService.page(new Query<>(params), new QueryWrapper<SysUser>().like("user_name",params.get("userName")));*/

        /*System.out.println("总条数 ------> " + userIPage.getTotal());
        System.out.println("当前页数 ------> " + userIPage.getCurrent());
        System.out.println("当前每页显示数 ------> " + userIPage.getSize());
        print(userIPage.getRecords());
        System.out.println("----- baseMapper 自带分页 ------");*/


        return userIPage;
    }
    private <T> void print(List<T> list) {
        if (!CollectionUtils.isEmpty(list)) {
            list.forEach(System.out::println);
        }
    }

    /**
     * 获取当前用户信息（角色、权限）
     * 并且异步初始化用户部门信息
     * @param  当前用户信息
     * @return 用户权限信息
     */
    @GetMapping("/userInfo")
    public R<UserInfo> userInfo(){
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication() .getPrincipal();
        UserVO userVO = userMapper.selectUserVoByUserName(userDetails.getUsername());
        UserInfo userInfo=userService.findUserInfo(userVO);

        return new R<>(userInfo) ;
    }

    /**
     * 新增用户信息
     * @param userDTO 用户信息
     * @return success/fail
     */
    @PostMapping("/addUser")
    public R<Boolean> addUser(@RequestBody UserDTO userDTO){
        SysUser sysUser=new SysUser();
        //通过反射将一个对象的值赋值个另外一个对象（前提是对象中属性的名字相同）。
        BeanUtils.copyProperties(userDTO,sysUser);
        sysUser.setPassword(ENCODER.encode(userDTO.getPassword()));
        //添加用户信息
        userService.save(sysUser);
        //遍历角色
        userDTO.getRoles().forEach(roleId->{
            SysUserRole userRole=new SysUserRole();
            userRole.setRoleId(roleId);
            userRole.setUserId(sysUser.getUserId());
            //添加角色信息
            userRole.insert();
        });
        return new R<>(Boolean.TRUE);
    }

    /**
     * 删除用户信息
     * @param userId  用户Id
     * @return success/fail
     */
    @DeleteMapping("/delUser/{userId}")
    public R<Boolean> delUser(@PathVariable Integer userId){
        SysUser sysUser = userService.getById(userId);
        return new R<>(userService.deleteUserById(sysUser));
    }


    /**
     * 更新用户信息
     * @param userDTO 用户信息
     * @return success/fail
     */
    @PutMapping("/updateUser")
    public R<Boolean> updateUser(@RequestBody UserDTO userDTO){
        return new R<>(userService.updateUser(userDTO));
    }
}

