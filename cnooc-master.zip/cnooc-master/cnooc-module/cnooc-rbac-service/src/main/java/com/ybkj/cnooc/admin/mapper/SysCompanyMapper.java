package com.ybkj.cnooc.admin.mapper;

import com.ybkj.cnooc.admin.model.SysCompany;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface SysCompanyMapper extends BaseMapper<SysCompany> {

}
