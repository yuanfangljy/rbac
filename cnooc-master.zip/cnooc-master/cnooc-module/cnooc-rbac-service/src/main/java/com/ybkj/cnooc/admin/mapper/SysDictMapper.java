package com.ybkj.cnooc.admin.mapper;

import com.ybkj.cnooc.admin.model.SysDict;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liujiayi
 * @since 2019-01-23
 */
public interface SysDictMapper extends BaseMapper<SysDict> {

    /**
     * 根据数据值和类型来获取对应的标签名
     * @param value 数值
     * @param type  类型
     * @return
     */
    String selectLabel(@Param("value") String value, @Param("type") String type);
}
