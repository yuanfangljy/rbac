package com.ybkj.cnooc.admin.mapper;

import com.ybkj.cnooc.admin.model.SysMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ybkj.cnooc.common.vo.MenuRoleVO;
import com.ybkj.cnooc.common.vo.MenuVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface SysMenuMapper extends BaseMapper<SysMenu> {

    /**
     * 根据角色编号查询菜单
     * @param roleCode 角色编码
     * @return 菜单列表
     */
    List<MenuVO> selectMenuByRoleCode(@Param("roleCode") String roleCode);

    /**
     * 查询所有的菜单以及相关角色
     * @return
     */
    List<MenuRoleVO> selectAllMenu();
}
