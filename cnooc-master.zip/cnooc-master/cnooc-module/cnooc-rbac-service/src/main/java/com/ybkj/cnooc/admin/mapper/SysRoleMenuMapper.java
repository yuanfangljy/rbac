package com.ybkj.cnooc.admin.mapper;

import com.ybkj.cnooc.admin.model.SysRoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * qwerqwer Mapper 接口
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-21
 */
public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {

}
