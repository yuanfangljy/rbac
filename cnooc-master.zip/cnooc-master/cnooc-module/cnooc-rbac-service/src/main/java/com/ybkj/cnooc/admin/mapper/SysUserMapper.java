package com.ybkj.cnooc.admin.mapper;

import com.ybkj.cnooc.admin.model.SysUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ybkj.cnooc.common.util.Query;
import com.ybkj.cnooc.common.vo.PermissionVO;
import com.ybkj.cnooc.common.vo.UserVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 用户表数据库层控制接口
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface SysUserMapper extends BaseMapper<SysUser> {

    /**
     * @param userName
     * @return
     */
    SysUser selectByUserName(@Param("userName") String userName);

    /**
     * 通过用户Id查询用户的权限，父类Id查询子权限
     * @param userId   用户Id
     * @param parentId 父类Id
     * @return         权限列表
     */
    List<PermissionVO> selectUserPermissionVOByUserIdOrMenuParendId(@Param("userId") Integer userId, @Param("parentId") Integer parentId);

    /**
     * 通过用户Id,查询用户信息
     * @param userId 用户id
     * @return 用户信息
     */
    UserVO selectUserVoById(@Param("userId") Integer userId);

    /**
     * 分页查询用户信息（含角色和）
     * @param query
     * @param userName
     * @return
     */
    List selectUserVoPageDateScope(@Param("userName") String userName,Query query);

    /**
     * 通过用户名查询用户信息（含有角色信息）
     *
     * @param username 用户名
     * @return userVo
     */
    UserVO selectUserVoByUserName(String username);
}
