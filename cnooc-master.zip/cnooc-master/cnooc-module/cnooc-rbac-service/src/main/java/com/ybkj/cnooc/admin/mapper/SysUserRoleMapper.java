package com.ybkj.cnooc.admin.mapper;

import com.ybkj.cnooc.admin.model.SysUserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

    /**
     * 根据用户Id，删除用户的角色关系
     * @param userId 用户ID
     * @return success/fail
     */
    Boolean deleteByUserId(@Param("userId") Integer userId);

    /**
     * 根据用户Id，查询角色数组
     * @param userId 用户Id
     * @return 角色数组
     */
    String[] seleteRoleIdByUserId(Integer userId);
}
