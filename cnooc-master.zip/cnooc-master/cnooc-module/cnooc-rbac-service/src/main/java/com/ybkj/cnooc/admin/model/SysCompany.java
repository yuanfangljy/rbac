package com.ybkj.cnooc.admin.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;
import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Data
public class SysCompany extends Model<SysCompany> {

    private static final long serialVersionUID = 1L;

    /**
     * 公司主键
     */
    @TableId(value = "company_id", type = IdType.AUTO)
    private Integer companyId;

    /**
     * 公司名称
     */
    private String name;

    /**
     * 公司电话
     */
    private String mobile;

    /**
     * 公司邮箱
     */
    private String mailbox;

    /**
     * 公司地址
     */
    private String address;

    /**
     * 排序
     */
    private Integer orderNum;

    /**
     * 负责人
     */
    private String principal;

    /**
     * 公司图像
     */
    private String avatar;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除  0：已删除  1：正常
     */
    private String delFlag;

    /**
     * 版本号
     */
    private Integer version;




    @Override
    protected Serializable pkVal() {
        return this.companyId;
    }

    @Override
    public String toString() {
        return "SysCompany{" +
        "companyId=" + companyId +
        ", name=" + name +
        ", mobile=" + mobile +
        ", mailbox=" + mailbox +
        ", address=" + address +
        ", orderNum=" + orderNum +
        ", principal=" + principal +
        ", avatar=" + avatar +
        ", createTime=" + createTime +
        ", updateTime=" + updateTime +
        ", delFlag=" + delFlag +
        ", version=" + version +
        "}";
    }
}
