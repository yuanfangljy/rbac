package com.ybkj.cnooc.admin.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Data
public class SysUser extends Model<SysUser> {

    private static final long serialVersionUID = 1L;

    /**
     * 用户主键
     */
    @TableId(value = "user_id", type = IdType.AUTO)
    private Integer userId;

    /**
     * 公司Id
     */
    private Integer companyId;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 密码
     */
    private String password;

    /**
     * 真实姓名
     */
    private String realName;

    /**
     * 随机盐
     */
    private String salt;

    /**
     * 图像
     */
    private String avatar;

    /**
     * 电话
     */
    private String mobile;

    /**
     * 邮箱
     */
    private String mailbox;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 0--删除 1--正常
     */
    private String delFlag;

    /**
     * 版本号
     */
    private Integer version;

    @Override
    protected Serializable pkVal() {
        return this.userId;
    }

   /* private List<SysRole> rolesList;*/
}
