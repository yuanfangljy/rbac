package com.ybkj.cnooc.admin.service;

import com.ybkj.cnooc.admin.model.SysDict;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liujiayi
 * @since 2019-01-23
 */
public interface ISysDictService extends IService<SysDict> {

    /**
     * 根据数据值和类型来获取对应的标签名
     * @param value 数值
     * @param type  类型
     * @return
     */
    String getLabel(String value, String type);
}
