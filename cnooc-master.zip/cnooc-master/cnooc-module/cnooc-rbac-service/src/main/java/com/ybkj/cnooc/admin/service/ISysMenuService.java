package com.ybkj.cnooc.admin.service;

import com.ybkj.cnooc.admin.model.SysMenu;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ybkj.cnooc.common.vo.MenuRoleVO;
import com.ybkj.cnooc.common.vo.MenuVO;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface ISysMenuService extends IService<SysMenu> {

    /**
     * 级联删除菜单
     *
     * @param menuId 菜单ID
     * @return 成功、失败
     */
    Boolean removeMenuByMenuId(Integer menuId);


    /**
     * 根据角色编码查询菜单
     * @param roleCode 角色编码
     * @return 菜单列表
     */
    List<MenuVO> findMenuByRoleCode(String roleCode);

    /**
     * 查询所有的菜单以及相关角色
     * @return
     */
    List<MenuRoleVO> getAllMenu();
}
