package com.ybkj.cnooc.admin.service;

import com.ybkj.cnooc.admin.model.SysRoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * qwerqwer 服务类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-21
 */
public interface ISysRoleMenuService extends IService<SysRoleMenu> {
    /**
     * 更新角色菜单
     *
     * @param roleCode  角色编码
     * @param roleId    角色Id
     * @param menuIds   菜单集合
     * @return success/fail
     */
    Boolean insertRoleMenus(String roleCode, Integer roleId, String menuIds);
}
