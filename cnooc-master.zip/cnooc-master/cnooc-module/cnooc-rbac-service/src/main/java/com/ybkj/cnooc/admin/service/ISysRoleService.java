package com.ybkj.cnooc.admin.service;

import com.ybkj.cnooc.admin.model.SysRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface ISysRoleService extends IService<SysRole> {



}
