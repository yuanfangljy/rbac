package com.ybkj.cnooc.admin.service;

import com.ybkj.cnooc.admin.model.SysUserRole;
import com.baomidou.mybatisplus.extension.service.IService;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface ISysUserRoleService extends IService<SysUserRole> {

    /**
     * 通过用户Id,查询角色id集合
     */
    String[] findRoleIdByUserId(@Param("userId") Integer userId);
}
