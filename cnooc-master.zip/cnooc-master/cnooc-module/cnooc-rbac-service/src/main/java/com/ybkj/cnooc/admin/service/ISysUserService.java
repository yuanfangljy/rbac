package com.ybkj.cnooc.admin.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ybkj.cnooc.admin.model.SysUser;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ybkj.cnooc.admin.model.dto.UserDTO;
import com.ybkj.cnooc.admin.model.dto.UserInfo;
import com.ybkj.cnooc.common.util.Query;
import com.ybkj.cnooc.common.vo.UserVO;
import org.springframework.security.core.userdetails.UserDetailsService;

/**
 * <p>
 *  服务类:用户
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
public interface ISysUserService extends IService<SysUser>  {

    SysUser getByUserName(String userName);

    /**
     * 更新用户信息
     * @param userDTO 用户信息
     * @return success/fail
     */
    Boolean updateUser(UserDTO userDTO);

    /**
     * 根据用户Id，查询用户信息
     * @param userId 用户ID
     * @return UserVo
     */
    UserVO getUserById(Integer userId);

    /**
     * 删除用户信息
     * @param sysUser 用户信息
     * @return success/fail
     */
    Boolean deleteUserById(SysUser sysUser);

    /**
     * 分页查询用户信息（角色）
     * @param objectQuery
     * @return
     */
    IPage selectWithRolePage(Query<Object> objectQuery);

    /**
     * 查询用户信息
     *
     * @param userVO 用户名
     * @return userInfo
     */
    UserInfo findUserInfo(UserVO userVO);
}
