package com.ybkj.cnooc.admin.service.impl;

import com.ybkj.cnooc.admin.model.SysCompany;
import com.ybkj.cnooc.admin.mapper.SysCompanyMapper;
import com.ybkj.cnooc.admin.service.ISysCompanyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Transactional
@Service
public class SysCompanyServiceImpl extends ServiceImpl<SysCompanyMapper, SysCompany> implements ISysCompanyService {

}
