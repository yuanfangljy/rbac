package com.ybkj.cnooc.admin.service.impl;

import com.ybkj.cnooc.admin.model.SysDict;
import com.ybkj.cnooc.admin.mapper.SysDictMapper;
import com.ybkj.cnooc.admin.service.ISysDictService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liujiayi
 * @since 2019-01-23
 */
@Service
public class SysDictServiceImpl extends ServiceImpl<SysDictMapper, SysDict> implements ISysDictService {

    @Autowired
    private SysDictMapper sysDictMapper;

    /**
     * 根据数据值和类型来获取对应的标签名
     * @param value 数值
     * @param type  类型
     * @return
     */
    @Override
    public String getLabel(String value, String type) {
        return sysDictMapper.selectLabel(value,type);
    }
}
