package com.ybkj.cnooc.admin.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.ybkj.cnooc.admin.model.SysMenu;
import com.ybkj.cnooc.admin.mapper.SysMenuMapper;
import com.ybkj.cnooc.admin.service.ISysMenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ybkj.cnooc.common.constant.CommonConstant;
import com.ybkj.cnooc.common.util.Assert;
import com.ybkj.cnooc.common.vo.MenuRoleVO;
import com.ybkj.cnooc.common.vo.MenuVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Transactional
@Service
public class SysMenuServiceImpl extends ServiceImpl<SysMenuMapper, SysMenu> implements ISysMenuService {

    @Autowired
    private SysMenuMapper menuMapper;

    /**
     * 级联删除菜单
     *
     * @param menuId 菜单ID
     * @return 成功、失败
     */
    @Override
    //@CacheEvict(value = "menu_details", allEntries = true)
    public Boolean removeMenuByMenuId(Integer menuId) {
        Assert.isNull(menuId, "菜单ID不能为空");
        //删除当前的菜单
        SysMenu menu1=new SysMenu();
        menu1.setMenuId(menuId);
        menu1.setDelFlag(CommonConstant.STATUS_DEL);
        menuMapper.updateById(menu1);

        // 删除父节点为当前节点的节点
        SysMenu menu2=new SysMenu();
        menu2.setParentId(menuId);
        SysMenu sysMenu=new SysMenu();
        sysMenu.setDelFlag(CommonConstant.STATUS_DEL);
        return menuMapper.update(sysMenu, new UpdateWrapper<>(menu2))>=1?true:false;
    }

    /**
     * 根据角色编号查询菜单
     * @param roleCode 角色编码
     * @return 菜单列表
     */
    @Override
    public List<MenuVO> findMenuByRoleCode(String roleCode) {
        return menuMapper.selectMenuByRoleCode(roleCode);
    }

    /**
     * 查询所有的菜单以及相关角色信息
     * @return
     */
    @Override
    public List<MenuRoleVO> getAllMenu() {
        return menuMapper.selectAllMenu();
    }
}
