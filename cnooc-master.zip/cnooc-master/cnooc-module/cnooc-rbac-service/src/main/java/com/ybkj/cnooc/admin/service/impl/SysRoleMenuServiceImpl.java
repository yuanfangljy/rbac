package com.ybkj.cnooc.admin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.xiaoleilu.hutool.util.StrUtil;
import com.ybkj.cnooc.admin.model.SysRoleMenu;
import com.ybkj.cnooc.admin.mapper.SysRoleMenuMapper;
import com.ybkj.cnooc.admin.service.ISysRoleMenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ybkj.cnooc.common.util.StringSplit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * qwerqwer 服务实现类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-21
 */
@Service
public class SysRoleMenuServiceImpl extends ServiceImpl<SysRoleMenuMapper, SysRoleMenu> implements ISysRoleMenuService {

    @Autowired
    private SysRoleMenuMapper sysRoleMenuMapper;
    @Autowired
    private ISysRoleMenuService sysRoleMenuService;
    /**
     * 更新角色菜单
     * @param roleCode  角色编码
     * @param roleId    角色Id
     * @param menuIds   菜单集合
     * @return success/fail
     */
    @Override
    public Boolean insertRoleMenus(String roleCode, Integer roleId, String menuIds) {
        //1、删除SysRoleMenu表中，角色为roleId的相关信息
        SysRoleMenu condition=new SysRoleMenu();
        condition.setRoleId(roleId);
        sysRoleMenuMapper.delete(new QueryWrapper<>(condition));

        if (StrUtil.isBlank(menuIds)) {
            return Boolean.TRUE;
        }

        //2、遍历menuIds数组新增角色菜单
        List<SysRoleMenu> roleMenuList = new ArrayList<>();
        String[] menus = StringSplit.slicerComma(menuIds);

        for (String menuId : menus) {
            SysRoleMenu roleMenu=new SysRoleMenu();
            roleMenu.setRoleId(roleId);
            roleMenu.setMenuId(Integer.valueOf(menuId));
            roleMenuList.add(roleMenu);
        }
        return sysRoleMenuService.saveBatch(roleMenuList);
    }
}
