package com.ybkj.cnooc.admin.service.impl;

import com.ybkj.cnooc.admin.model.SysRole;
import com.ybkj.cnooc.admin.mapper.SysRoleMapper;
import com.ybkj.cnooc.admin.service.ISysRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Transactional
@Service
public class SysRoleServiceImpl extends ServiceImpl<SysRoleMapper, SysRole> implements ISysRoleService {


}
