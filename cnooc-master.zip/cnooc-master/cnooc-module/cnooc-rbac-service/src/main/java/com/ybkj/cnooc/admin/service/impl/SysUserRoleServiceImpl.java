package com.ybkj.cnooc.admin.service.impl;

import com.ybkj.cnooc.admin.model.SysUserRole;
import com.ybkj.cnooc.admin.mapper.SysUserRoleMapper;
import com.ybkj.cnooc.admin.service.ISysUserRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Transactional
@Service
public class SysUserRoleServiceImpl extends ServiceImpl<SysUserRoleMapper, SysUserRole> implements ISysUserRoleService {

    @Autowired
    private SysUserRoleMapper userRoleMapper;

    /**
     * 通过用户Id,查询角色id集合
     */
    @Override
    public String[] findRoleIdByUserId(Integer userId) {
        String[]  rolse=userRoleMapper.seleteRoleIdByUserId(userId);
        System.out.println(rolse);
        return userRoleMapper.seleteRoleIdByUserId(userId);
    }
}
