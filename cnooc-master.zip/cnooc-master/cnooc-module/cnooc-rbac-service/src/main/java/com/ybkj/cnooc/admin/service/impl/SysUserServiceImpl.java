package com.ybkj.cnooc.admin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.xiaoleilu.hutool.util.ArrayUtil;
import com.xiaoleilu.hutool.util.StrUtil;
import com.ybkj.cnooc.admin.common.security.UserDetailsImpl;
import com.ybkj.cnooc.admin.common.util.Encrypted;
import com.ybkj.cnooc.admin.mapper.SysMenuMapper;
import com.ybkj.cnooc.admin.mapper.SysUserRoleMapper;
import com.ybkj.cnooc.admin.model.SysUser;
import com.ybkj.cnooc.admin.mapper.SysUserMapper;
import com.ybkj.cnooc.admin.model.SysUserRole;
import com.ybkj.cnooc.admin.model.dto.UserDTO;
import com.ybkj.cnooc.admin.model.dto.UserInfo;
import com.ybkj.cnooc.admin.service.ISysUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ybkj.cnooc.common.constant.CommonConstant;
import com.ybkj.cnooc.common.constant.SecurityConstants;
import com.ybkj.cnooc.common.util.Query;
import com.ybkj.cnooc.common.vo.MenuVO;
import com.ybkj.cnooc.common.vo.SysRole;
import com.ybkj.cnooc.common.vo.UserVO;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author liujiayi
 * @since 2018-12-20
 */
@Transactional
@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements ISysUserService,UserDetailsService {

    @Autowired
    private SysUserMapper userMapper;
    @Autowired
    private SysUserRoleMapper userRoleMapper;
    @Autowired
    private SysMenuMapper menuMapper;

    /**
     * Security 进行登录授权：根据用户名查询用户信息
     *
     * @param username
     * @return
     * @throws UsernameNotFoundException
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //System.out.println("用户名"+username);
        //查询用户信息
        UserVO userVo = userMapper.selectUserVoByUserName(username);
        if (userVo == null) {
            throw new UsernameNotFoundException("用户名不存在或者密码错误");
        }
        /*List<PermissionVO> permissionVO=userMapper.selectUserPermissionVOByUserIdOrMenuParendId(userVo.getUserId(),null);
        if(permissionVO.size()<=0 || permissionVO==null){
            throw new DisabledException("暂无权限");
        }*/
        return new UserDetailsImpl(userVo/*,permissionVO*/);
    }

    /*
     *根据用户名查询用户信息
     */
    @Override
    public SysUser getByUserName(String userName) {
        return userMapper.selectByUserName(userName);
    }

    /**
     * 更新用户信息
     * @param userDTO 用户信息
     * @return success/fail
     */
    @Override
    //@CacheEvict(value = "user_details", key = "#userDto.userName")
    public Boolean updateUser(UserDTO userDTO) {
        //1、修改用户信息
        SysUser sysUser=new SysUser();
        BeanUtils.copyProperties(userDTO,sysUser);
        sysUser.setPassword(Encrypted.getPassword(userDTO.getPassword()));
        sysUser.setUpdateTime(new Date());
        userMapper.updateById(sysUser);
        //2、修改角色信息
        SysUserRole condition = new SysUserRole();
        condition.setUserId(userDTO.getUserId());
        System.out.println(condition.toString());
        //根据对象，删除相关角色信息
       userRoleMapper.deleteByUserId(userDTO.getUserId());
        //3、新增角色信息
        userDTO.getRoles().forEach(roleId->{
            SysUserRole userRole=new SysUserRole();
            userRole.setUserId(sysUser.getUserId());
            userRole.setRoleId(roleId);
            userRole.insert();
        });
        return Boolean.TRUE;
    }

    /**
     * 根据用户Id，查询用户信息
     * @param userId 用户ID
     * @return UserVo
     */
    @Override
    public UserVO getUserById(Integer userId) {
        return userMapper.selectUserVoById(userId);
    }


    /**
     * 删除用户信息
     * @param sysUser 用户信息
     * @return success/fail
     */
    @Override
    public Boolean deleteUserById(SysUser sysUser) {
        //1、删除用户的相关的角色信息
        userRoleMapper.deleteByUserId(sysUser.getUserId());
        //2、删除用户信息
        sysUser.setDelFlag(CommonConstant.STATUS_DEL);
        userMapper.updateById(sysUser);
        return Boolean.TRUE;
    }

    /**
     * 分页查询用户信息（角色）
     * @param query
     * @return
     */
    @Override
    public IPage selectWithRolePage(Query<Object> query) {
        String username = (String) query.condition().get("userName");
        query.setRecords(userMapper.selectUserVoPageDateScope(username,query));
        return query;
    }

    /**
     * 查询用户信息
     *
     * @param userVO 角色名
     * @return userInfo
     */
    @Override
    public UserInfo findUserInfo(UserVO userVO) {
        //1、查询用户基本信息
        SysUser condition = new SysUser();
        condition.setUserName(userVO.getUserName());
        SysUser sysUser= userMapper.selectOne(new QueryWrapper<>(condition));

        UserInfo userInfo=new UserInfo();
        userInfo.setSysUser(sysUser);

        //2、设置角色列表
        List<String> roleCodes=userVO.getRoleList().stream()
                .filter(sysRole -> !StrUtil.equals(SecurityConstants.BASE_ROLE,sysRole.getRoleCode()))
                .map(SysRole::getRoleCode)
                .collect(Collectors.toList());
        String[] roles = ArrayUtil.toArray(roleCodes, String.class);
        userInfo.setRoles(roles);

        //3、设置权限列表（menu.permission）
        Set<String> permissions=new HashSet<>();
        Arrays.stream(roles).forEach(roleName->{
            //根据角色查询用户权限，进行迭代
            List<MenuVO> menuVOS = menuMapper.selectMenuByRoleCode(roleName);
            List<String> permissionList = menuVOS.stream()
                    .filter(menuVo -> StringUtils.isNotEmpty(menuVo.getPermission()))
                    .map(MenuVO::getPermission).collect(Collectors.toList());
            permissions.addAll(permissionList);
        });
        userInfo.setPermissions(ArrayUtil.toArray(permissions, String.class));
        return userInfo;
    }

}
