######## 1、根据用户名，查询用户的权限  ########
SELECT 
	   sm.menu_id AS menuId,sm.menu_name AS menuName,
           sm.permission AS permission, sm.path AS path,
           sm.url AS url,sm.method AS method,
           sm.parent_id AS parentId,sm.icon AS icon,
           sm.component AS component,sm.sort AS sort,sm.type AS TYPE
           
         FROM sys_user AS su
         INNER JOIN sys_user_role AS syr ON su.user_id = syr.user_id
         INNER JOIN sys_company AS sc ON su.company_id = sc.company_id
         INNER JOIN sys_role_menu AS srm ON srm.role_id = syr.role_id
         INNER JOIN sys_menu AS sm ON sm.menu_id = srm.menu_id
         WHERE sm.del_flag=1 AND su.user_id=1
         GROUP BY sm.menu_id
         ORDER BY sm.sort ASC
         
   ######## 2、根据角色编号查询菜单  ########
   SELECT * FROM sys_role AS sr
            INNER JOIN sys_role_menu AS srm ON sr.role_id = srm.role_id
            INNER JOIN sys_menu AS sm ON sm.menu_id = srm.menu_id
            WHERE 
            sr.del_flag = 0 AND
            sm.del_flag = 0 AND 
            sr.role_code=  
            ORDER BY sm.sort DESC
            
   ######## 3、根据用户Id，查询用户信息  ########
   SELECT su.user_id,su.`user_name`,su.`password`,su.`real_name`,su.`salt`,
          su.`mobile`,su.`avatar`,su.`create_time`,su.`update_time`,su.`del_flag`,
          sr.role_id,sr.role_name,sr.role_code,
          sc.`company_id`,sc.`name`
            FROM sys_user AS su
            LEFT JOIN sys_user_role AS sur ON su.user_id=sur.user_id
            LEFT JOIN sys_role AS sr ON sr.role_id=sur.role_id
            LEFT JOIN sys_company AS sc ON sc.company_id=su.company_id
            WHERE su.user_id=1
            
         
         