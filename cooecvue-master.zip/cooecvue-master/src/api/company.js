import request from '@/router/axios';

/**
 * 公司列表信息
 * @param {*} query 
 */
export const getCompanyData = (query)=> {
    return request({
    url: '/admin/sysCompany/companyPage',
    method: 'get',
    params: query
   })
}

/**
 * 删除公司
 * @param {*} query 
 */
export const delObj = (cId)=> {
    return request({
    url: '/admin/sysCompany/delCompany/'+cId,
    method: 'delete',
   })
}

/**
 * 新增公司
 * @param {*} query 
 */
export const addObj = (date)=> {
    return request({
    url: '/admin/sysCompany/addCompany',
    method: 'post',
    data: date
   })
}

/**
 * 修改公司
 * @param {*} query 
 */
export const putObj = (date)=> {
    return request({
    url: '/admin/sysCompany/updateCompany',
    method: 'put',
    data: date
   })
}
