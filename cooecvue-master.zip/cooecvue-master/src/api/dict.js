import request from '@/router/axios'


/**
 * 字典列表信息
 * @param {*} query 
 */
export const getDictData = (query)=> {
    return request({
    url: '/admin/sysDict/dictPage',
    method:'get',
    params: query
   })
}

export const getLabel = (value,type)=> {
  //alert("进入方法")
  return request({
  url: '/admin/sysDict/getLabel',
  method:'get',
  params: { value, type}
 })
}


export function addObj(obj) {
  return request({
    url: '/admin/sysDict/addDict',
    method: 'post',
    data: obj
  })
}

export function getObj(id) {
  return request({
    url: '/admin/sysDict/' + id,
    method: 'get'
  })
}

export function delObj(row) {
  return request({
    url: '/admin/sysDict/delDict/' + row.dictId + '/' + row.type,
    method: 'delete'
  })
}

export function putObj(obj) {
  return request({
    url: '/admin/sysDict/updateDict',
    method: 'put',
    data: obj
  })
}

export function remote(type) {
  return request({
    url: '/admin/sysDict/type/' + type,
    method: 'get'
  })
}
