import request from '@/router/axios';

export function fetchTree(query) {
    return request({
      url: '/admin/sysMenu/allTree',
      method: 'get',
      params: query
    })
  }

  export function addObj(obj) {
    return request({
      url: '/admin/sysMenu/addMenu',
      method: 'post',
      data: obj
    })
  }
  
  export function getObj(menuId) {
    return request({
      url: '/admin/sysMenu/' + menuId,
      method: 'get'
    })
  }
  
  export function delObj(id) {
    return request({
      url: '/admin/sysMenu/delMenu/' + id,
      method: 'delete'
    })
  }
  
  export function putObj(obj) {
    return request({
      url: '/admin/sysMenu/updateMenu',
      method: 'put',
      data: obj
    })
  }
  