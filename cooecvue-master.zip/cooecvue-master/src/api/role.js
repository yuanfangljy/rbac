import request from '@/router/axios';


/**
 * 获取角色列表
 * @param {*} page 分页参数
 */
export const getRoleData = (page) =>{
    return request({
        url: '/admin/sysRole/rolePage',
        method: 'get',
        params: page 
    })
    
} 

/**
 * 根据角色名称，查询权限信息
 * @param {*} roleName  
 */
/* export const fetchRoleTree = (roleCode) =>{
    return request({
        url: '/admin/sysMenu/getRoleTree/'+roleCode,
        method: 'get',
    })
} */

export function fetchRoleTree(roleCode) {
    return request({
      url: '/admin/sysMenu/getRoleTree/' + roleCode,
      method: 'get'
    })
  }

/**
 * 更新角色，权限列表
 * @param {*} roleId
 * @param {*} menuIds    
 */
export const permissionUpd = (roleId, menuIds) =>{
    return request({
        url: '/admin/sysRole/updateRoleTree',
        method: 'put',
        params: {
            roleId: roleId,
            menuIds: menuIds
        }
    })
}


/**
 * 添加角色基本信息
 * @param {*} data  新增数据
 */
export const addObj = (data) =>{
    return request({
        url: '/admin/sysRole/addRole',
        method: 'post',
        data: data 
    })
    
}

/**
 * 删除角色
 * @param {*} roleId 
 */

export const delObj = (roleId) =>{
    return request({
        url: '/admin/sysRole/delRole/'+roleId,
        method: 'delete',
    })
}


/**
 * 修改角色基本信息
 * @param {*} data 
 */
 export const putObj = (data) =>{
    return request({
        url: '/admin/sysRole/updateRole',
        method: 'put',
        data: data 
    })
    
}


