import request from '@/router/axios';
/**
 * 用户登录接口
 * @param {*} username 
 * @param {*} password 
 * @param {*} code 
 * @param {*} redomStr 
 */
export const loginByUsername = (username, password, code, redomStr) => {
    return request({
        url: '/admin/sysUser/login',
        headers: {
            'Authorization': 'Basic cGlnOnBpZw=='
          },
        method: 'post',
        params: { username, password}
    })
}

/**
 * 用户列表信息
 * @param {*} query 
 */
export const getUserData = (query)=> {
    return request({
    url: '/admin/sysUser/userPage',
    method: 'get',
    params: query
   })
}

/**
 * 删除用户
 * @param {*} query 
 */
export const delObj = (userId)=> {
    return request({
    url: '/admin/sysUser/delUser/'+userId,
    method: 'delete',
   })
}

/**
 * 新增用户
 * @param {*} query 
 */
export const addObj = (date)=> {
    return request({
    url: '/admin/sysUser/addUser',
    method: 'post',
    data: date
   })
}

/**
 * 修改用户
 * @param {*} query 
 */
export const putObj = (date)=> {
    return request({
    url: '/admin/sysUser/updateUser',
    method: 'put',
    data: date
   })
}

/**
 * 用户基本信息，权限，角色接口
 */
export const getUserInfo = () =>{ 
    return request({
    url: '/admin/sysUser/userInfo',
    method: 'get'
   });
}
export const RefeshToken = () => request({
    url: '/user/refesh',
    method: 'post'
})

export const getMenu = (username) => {
   // alert("进入菜单");
    return request({
        url: '/admin/sysMenu/userMenu',
        method: 'get',
        params: { username}
    });
}

export const getMenuAll = () => request({
    url: '/user/getMenu',
    method: 'get',
    data: {
        type: 0
    }
});

export const getTableData = (page) => request({
    url: '/user/getTable',
    method: 'get',
    data: {
        page
    }
});

export const logout = () => request({
    url: '/user/logout',
    method: 'get'
})