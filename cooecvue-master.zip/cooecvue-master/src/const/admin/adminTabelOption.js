import {DIC} from '@/const/dic'
export const userOption = {
    
    border: true,
    index: true,
    indexLabel: '序号',
    selection: true,
    menuBtn: true,
    menuAlign: 'center',
    align: "center",
    //dicData: DIC,
    dicUrl:'admin/sysDict/type/{{key}}',
    delBtn:true,
    editBtn:false,
    menuType:"text",
    column: [
        {
            label: "用户名",
            prop: "userName",
            width: 180,
            fixed: true,
            search:true,
            solt: true,//自定义
            sortable: true,
            rules: [{
              required: true,
              message: "请输入用户名",
              trigger: "blur"
            }]
          },

          {
            label: "密码",
            prop: "password",
            width: 180,
            //span: 24,
            fixed: true,
            hide: true,
            //solt: true,
            rules: [{
              required: true,
              message: "请输入密码",
              trigger: "blur"
            }]
          },
          {
            label: "姓名",
            prop: "realName",
            width: 180,
            formHeight: 'auto',
            //span: 24,
            fixed: true,
            hide: true,
            //solt: true,
            rules: [{
              required: true,
              message: "请输入真实姓名",
              trigger: "blur"
            }]
          },
        {
            label: "手机号",
            prop: "mobile",
            width: "150",
            fixed: true,
            rules: [{
                required: true,
                message: "请输入手机号",
                trigger: "blur"
               },{
                min: 11,
                max: 11,
                message: "长度在11 个字符",
                trigger: "blur"
              }]
        },
        {
            label: "邮箱",
            prop: "mailbox",
            width: "150",
            fixed: true,
            hide: true,
            rules: [{
                required: true,
                message: "请输入邮箱",
                trigger: "blur"
            }]
        },
       /*   {
            label: "角色",
            prop: "grade",
            hide: true,
            type: "checkbox",
            dicData: 'GRADE'
        },  */
        {
            label: "所属公司",
            prop: "companyId",
            type: "select",
            //formHeight: 'auto',
           // dicUrl:'admin/sysCompany/selectCompanyById/{{key}}',
            hide: true,
            dicData:'COMPANY_TYPE',
            /* props: {
                label: 'type',
                value: 'value'
            },  */
        },
        {
            label: "角色",
            prop: "roles",
            type: "select",
            //solt: true,
            //hide: true,
            multiple:true,
            dicData: 'ROLE_TYPE',
           /*  dicData:[{
                label:'有权限',
                value:'1'
              },{
                label:'无权限',
                value:'2'
              },{
                label:'禁止项',
                disabled:true,
                value:'3'
              }], */
            span:12,
        }, 
        {
            label: "状态",
            prop: "delFlag",
            type: "select",
            width: "150",
            //solt: true,
            dicData:'DEL_FLAG',
            span:12,
            //自行配置dict中取值的属性
            /* props: {
                label: 'type',
                value: 'value'
            }, */
           /*  filters:[{ text: '男', value: '0' }, { text: '女', value: '1' }],
            filterMethod:function(value, row, column) {
                alert(value)
              return row.delFlag === value;
            } */
        }, 
        {
            label: "创建时间",
            visdiplay:false,
            prop: "createTime",
            type: "datetime",
            format: "yyyy-MM-dd HH:mm:ss",
            valueFormat: "yyyy-MM-dd HH:mm:ss",
        },
      
         
       /*  {
            label: "状态",
            prop: "version",
            solt: true,
            type: "radio",
            dicData: 'SEX'
        }   */
    ]
};
export const roleOption = {
    border: true,
    index: true,
    selection: false,
    indexLabel: '序号',
    calcHeight: 10,
    menuBtn: true,
    align: "center",
    menuAlign: 'center',
    menuWidth: 320,
    menuType:"text",
    column: [
        {
            label: "角色名称",
            prop: "roleName",
            search:true,
           // width: "180",
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入角色名称",
                trigger: "blur"
            }]
        },
        {
            label: "角色标识",
            prop: "roleCode",
            //width: "180",
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入角色标识",
                trigger: "blur"
            }]
        },
        {
            label: "角色描述",
            prop: "roleDesc",
            //width: "180",
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入角色描述",
                trigger: "blur"
            }]
        },
        {
            label: "创建时间",
            prop: "createTime",
            visdiplay:false,
            format: "yyyy-MM-dd HH:mm:ss",
            valueFormat: "yyyy-MM-dd HH:mm:ss",
            type: "date",
        }
    ]
};




export const companyOption = {
    border: true,
    index: true,
    selection: false,
    indexLabel: '序号',
    calcHeight: 10,
    menuBtn: true,
    align: "center",
    menuAlign: 'center',
    menuType:"text",
    //menuWidth: 320,
    column: [
        /* {
            label: "图像",
            prop: "avatar",
            type: "upload",
            imgWidth:100,
            //listType:'picture-card',
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入公司图像",
                trigger: "blur"
            }]
        }, */

        /* {
            label: '照片墙',
            prop: 'imgUrl',
            type: 'upload',
            span: 24,
            listType: 'picture-card',
            tip: '只能上传jpg/png文件，且不超过500kb',
            action: 'https://jsonplaceholder.typicode.com/posts/'
        }, */
        {
            label: "公司名称",
            prop: "name",
            search:true,
           // width: "180",
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入公司名称",
                trigger: "blur"
            }]
        },
        {
            label: "负责人",
            prop: "principal",
            //width: "180",
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入公司负责人名称",
                trigger: "blur"
            }]
        },
        {
            label: "公司电话",
            prop: "mobile",
            //width: "180",
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入公司电话",
                trigger: "blur"
            }]
        },
        {
            label: "公司邮箱",
            prop: "mailbox",
            //width: "180",
            fixed: true,
            hide: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入公司邮箱",
                trigger: "blur"
            }]
        },
        {
            label: "公司地址",
            prop: "address",
            //width: "180",
            fixed: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入公司地址",
                trigger: "blur"
            }]
        },
        {
            label: "排序号",
            prop: "orderNum",
            fixed: true,
            hide: true,
            span:24,
            rules: [{
                required: true,
                message: "请输入公司排序号",
                trigger: "blur"
            }]
        },
     
     
        {
            label: "创建时间",
            prop: "createTime",
            visdiplay:false,
            format: "yyyy-MM-dd HH:mm:ss",
            valueFormat: "yyyy-MM-dd HH:mm:ss",
            type: "date",
        }
    ]
};


export const dictOption = {
    border: true,
    index: true,
    selection: true,
    indexLabel: '序号',
    calcHeight: 10,
    menuBtn: true,
    align: "center",
    menuAlign: 'center',
    dicData: DIC,
    column: [
        {
            label: "数据值",
            prop: "value",
            fixed: true,
            rules: [{
                required: true,
                message: "请输入数据值",
                trigger: "blur"
            }]
        },
        {
            label: "标签名",
            prop: "label",
            //width: "180",
            fixed: true,
            rules: [{
                required: true,
                message: "请输入标签名",
                trigger: "blur"
            }]
        },
        {
            label: "类型",
            prop: "type",
            search:true,
            fixed: true,
            rules: [{
                required: true,
                message: "请输入类型",
                trigger: "blur"
            }]
        },
        {
            label: "描述",
            prop: "description",
            //width: "180",
            fixed: true,
            hide: true,
            rules: [{
                required: true,
                message: "请输入描述",
                trigger: "blur"
            }]
        },
        {
            label: "排序",
            prop: "sort",
            //width: "180",
            fixed: true,
            rules: [{
                required: true,
                message: "请输入排序",
                trigger: "blur"
            }]
        },
         {
            label: "状态",
            prop: "delFlag",
            type:"select",
            //fixed: true,
            hide: true,
            dicData: 'STATE',
            rules: [{
                required: true,
                message: "请选择状态",
                trigger: "blur"
            }]
        }, 
       
        {
            label: "备注信息",
            prop: "remarks",
            fixed: true,
            hide: true,
            rules: [{
                required: true,
                message: "请输入备注信息",
                trigger: "blur"
            }]
        },
    ]
};