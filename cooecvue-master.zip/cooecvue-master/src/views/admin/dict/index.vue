<template>
    <div>
        <basic-container>
              <avue-crud :option="tableOption"
                 :data="tableData"
                 :table-loading="tableLoading"
                 :page="page"
                 ref="crud"
                 @row-save="handleSave"
                 @row-update="handleUpdate"
                 @row-del="handleDel"
                 @current-change="currentChange"
                 @size-change="sizeChange"
                 @search-change="searchChange"
                 @refresh-change="refreshChange"
                 >
       <!--  <template slot-scope="scope"
                  slot="state">
          <el-tag :type="scope.row.userName!=''?'success':'danger'">1123</el-tag>
        </template> -->
      </avue-crud>
        </basic-container>
    </div>
</template>

<script>
import { mapGetters } from "vuex";
import { getDictData,delObj,putObj,addObj } from '@/api/dict'
import { dictOption } from "@/const/admin/adminTabelOption.js";
export default {
    name:"dict",
    components: {},
    data () {
        return {
        tableOption: dictOption, //表格设置属性
        tableData: [], //表格的数据
        tableLoading: false,
        page: {
            total: 0, //总页数
            currentPage: 1, //当前页数
            pageSize: 10 //每页显示多少条
        },
        dictType:"",
        };
    },
    created () {
      this.handleList();
    },
    methods:{
           /**
     * @title 获取数据
     * @detail 赋值为tableData表格即可
     *
     **/
    handleList () {
      this.tableLoading = true;
      getDictData({currentPage : `${this.page.currentPage}`, pageSize:`${this.page.pageSize}` , type:`${this.dictType}`})
        .then(res => {
          const data = res.data;
          setTimeout(() => {
            this.tableData = data.records;
              this.page = {
              total: data.total,
              pageSize: data.size,
              currentPage: data.current
            };  
            this.tableLoading = false;
          }, 1000);
        });
    },
    currentChange(val) {
      //alert(val)
      this.page.currentPage = val
      this.handleList()
    },
    sizeChange(val) {
      this.page.pageSize = val
      this.handleList()
    },
    /**
     * 根据用户名查询
     */
    searchChange(params){
      this.page.currentPage=1
      this.dictType=params.type
      this.handleList()
    },
    /**
     * 刷新
     */
    refreshChange({page,searchForm}){
      this.dictType=""
      this.handleList()
     },
    /**
     * @title 数据添加
     * @param row 为当前的数据
     * @param done 为表单关闭函数
     *
     **/
    handleSave (row, done) {
      addObj(row).then(res=>{
        this.tableData.push(row);
        this.$notify({
            title: '成功',
            message: '添加成功',
            type: 'success',
            duration: 2000
        })
         this.handleList()
          done();
      })
     
     
    },
    /**
     * @title 数据删除
     * @param row 为当前的数据
     * @param index 为当前更新数据的行数
     *
     **/
    handleDel (row, index) {
      this.$confirm(`是否确认删除标签为 ${row.label} ,数据类型为 ${row.type} 的数据项`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          delObj(row).then(res => {
            this.tableData.splice(index, 1);
              this.handleList()
            this.$notify({
                title: '成功',
                message: '删除成功',
                type: 'success',
                duration: 2000
            })
      })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });  
         });
    },
    /**
     * @title 数据更新
     * @param row 为当前的数据
     * @param index 为当前更新数据的行数
     * @param done 为表单关闭函数
     *
     **/
    handleUpdate (row, index, done) {
       this.$message.success('搜索数据'+ JSON.stringify(row));
     putObj(row).then(data => {
        this.tableData.splice(index, 1, Object.assign({}, row))
          this.$notify({
          title: '成功',
          message: '修改成功',
          type: 'success',
          duration: 2000
        })
        done()
        this.handleList()
      })
    },
    }
}
</script>

