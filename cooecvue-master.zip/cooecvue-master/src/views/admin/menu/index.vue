<template>
  <div>
    <basic-container>
      <el-container>
        <el-header class="menu-header">
          <el-button-group>
            <el-button type="primary"
                       icon="el-icon-plus"
                       size="small"
                       @click.native="handleAdd"
                       v-if="permissions.sys_menu_btn_add">新增</el-button>
            <el-button type="primary"
                       icon="el-icon-edit"
                       size="small"
                       @click.native="handleEdit"
                       v-if="permissions.sys_menu_btn_edit">编辑</el-button>
            <el-button type="primary"
                       icon="el-icon-delete"
                       size="small"
                       @click.native="handleDel"
                       v-if="permissions.sys_menu_btn_del">删除</el-button>
          </el-button-group>
        </el-header>
      </el-container>
      
      <el-container>
        <el-aside width="300px">
          
       <!--    <el-tree :data="menuAll"
                   node-key="id"
                   highlight-current
                   default-expand-all
                   :expand-on-click-node="false"
                   @node-click="handleNodeClick">
          </el-tree> -->

          <el-tree
          class="filter-tree"
          node-key="id"
          highlight-current
          :data="treeData"
          :default-expanded-keys="aExpandedKeys"
          :filter-node-method="filterNode"
          :props="defaultProps"
          @node-click="getNodeData"
          @node-expand="nodeExpand"
          @node-collapse="nodeCollapse">
        </el-tree>

        </el-aside>
        <el-main>
           <el-form :label-position="labelPosition" label-width="80px" :model="form" :rules="rules" ref="form">
            <el-form-item label="父级节点" prop="parentId">
              <el-input v-model="form.parentId" :disabled="true" placeholder="请输入父级节点"></el-input>
            </el-form-item>
            <el-form-item label="节点ID" prop="menuId">
              <el-input v-model="form.menuId" :disabled="formEdit" placeholder="请输入节点ID"></el-input>
            </el-form-item>
            <el-form-item label="菜单名称" prop="menuName">
              <el-input v-model="form.menuName" :disabled="formEdit"  placeholder="请输入菜单名称"></el-input>
            </el-form-item>
            <el-form-item label="权限标识" prop="permission">
              <el-input v-model="form.permission" :disabled="formEdit" placeholder="请输入权限标识"></el-input>
            </el-form-item>
            <el-form-item label="图标" prop="icon">
              <el-input v-model="form.icon" :disabled="formEdit" placeholder="请输入图标"></el-input>
            </el-form-item>
            <el-form-item label="资源路径" prop="url">
              <el-input v-model="form.url" :disabled="formEdit" placeholder="请输入资源路径"></el-input>
            </el-form-item>
            <el-form-item label="请求方法" prop="method">
              <el-select class="filter-item" v-model="form.method"  :disabled="formEdit"  placeholder="请输入资源请求类型">
                <el-option v-for="item in  methodOptions" :key="item" :label="item" :value="item"> </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="类型" prop="type">
              <el-select class="filter-item" v-model="form.type"  :disabled="formEdit"  placeholder="请输入资源请求类型">
                <el-option v-for="item in  typeOptions" :key="item" :label="item | typeFilter" :value="item"> </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="排序" prop="sort">
              <el-input v-model="form.sort" :disabled="formEdit" placeholder="请输入排序"></el-input>
            </el-form-item>
            <el-form-item label="前端组件"   prop="component">
              <el-input v-model="form.component" :disabled="formEdit" placeholder="请输入描述"></el-input>
            </el-form-item>
            <el-form-item label="前端地址"   prop="component">
              <el-input v-model="form.path" :disabled="formEdit" placeholder="iframe嵌套地址"></el-input>
            </el-form-item>
            <el-form-item v-if="formStatus == 'update'">
              <el-button type="primary" @click="update('form')">更新</el-button>
              <el-button @click="onCancel">取消</el-button>
            </el-form-item>
            <el-form-item v-if="formStatus == 'create'">
              <el-button type="primary" @click="create('form')">保存</el-button>
              <el-button @click="onCancel">取消</el-button>
            </el-form-item>
          </el-form>
        </el-main>
      </el-container>
    </basic-container>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { fetchTree, getObj, addObj, delObj, putObj } from '@/api/menu'
import { validatenull } from "@/util/validate";
import { findParent } from "@/util/util";
export default {
  name: "menu",
  data () {
    return {
      form: {},
      obj: {},
      parentForm: {},
      formGrade: true,
      formStatus: "",


      formEdit: true,
      formAdd: true,
      treeData: [],
      aExpandedKeys: [],
      showElement: false,
      currentId: 0,
      labelPosition: 'right',
      methodOptions: ['GET', 'POST', 'PUT', 'DELETE'],
      typeOptions: ['0', '1'],
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      oExpandedKey: {
          // key (from tree id) : expandedOrNot boolean
      },
      oTreeNodeChildren: {
          // id1 : [children] (from tree node id1)
          // id2 : [children] (from tree node id2)
      },
      form: {
          permission: undefined,
          menuName: undefined,
          menuId: undefined,
          parentId: undefined,
          url: undefined,
          icon: undefined,
          sort: undefined,
          component: undefined,
          type: undefined,
          method: undefined,
          path: undefined
        },
        rules:{
          parentId: [
            { required: true, message: '请不要篡改数据', trigger: 'blur' },
          ],
        /*   menuId: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ], */
          
          menuName: [
            { required: true, message: '请输入菜单名称', trigger: 'blur' },
            { min: 1, max: 10, message: '长度在 3 到 10 个字符', trigger: 'blur' }
          ],
          permission: [
            { required: true, message: '请输入权限标识', trigger: 'blur' },
          ],
          
          url: [
            { required: true, message: '请输入请求资源路径', trigger: 'blur' },
            //{ min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
         /*  icon: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ], */
          /* sort: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
          component: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
          type: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
          method: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ],
          path: [
            { required: true, message: '请输入活动名称', trigger: 'blur' },
            { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
          ], */
        }

    };
  },
  created () {
    this.getList();
    //this.$store.dispatch("GetMenuAll").then(() => { });
  },
  filters: {
      typeFilter(type) {
        const typeMap = {
          0: '菜单',
          1: '按钮'
        }
        return typeMap[type]
      }
    },
  mounted () { },
  computed: {
    ...mapGetters(["permissions", "menuAll"])
  },
  props: [],
  methods: {
    /**
     * 查询全部菜单
     */
    getList() {
        fetchTree(this.listQuery).then(response => {
          this.treeData = response.data
        })
      },
    filterNode(value, data) {
        // console.log(value);
        if (!value) return true
        return data.label.indexOf(value) !== -1
    },
    setExpandedKeys() {
    let oTemp = this.oExpandedKey
    this.aExpandedKeys = []
    for (let sKey in oTemp) {
        if (oTemp[sKey]) {
          this.aExpandedKeys.push(parseInt(sKey));
        }
      }
    },
    treeRecursion(aChildren, fnCallback) {
      if (aChildren) {
        for (let i = 0; i < aChildren.length; ++i) {
          let oNode = aChildren[i]
          fnCallback && fnCallback(oNode)
          this.treeRecursion(oNode.children, fnCallback)
        }
      }
    },

    nodeExpand(data) {
        let aChildren = data.children
        if (aChildren.length > 0) {
          this.oExpandedKey[data.id] = true
          this.oTreeNodeChildren[data.id] = aChildren
        }
        this.setExpandedKeys()
    },
    nodeCollapse(data) {
      this.oExpandedKey[data.id] = false
      // 如果有子节点
      this.treeRecursion(this.oTreeNodeChildren[data.id], (oNode) => {
        this.oExpandedKey[oNode.id] = false
      });
      this.setExpandedKeys()
    },
    
    /**
     * 根据菜单/按钮Id，获取到对应的消息，赋值给form
     */
    getNodeData(data) {
      if (!this.formEdit) {
        this.formStatus = 'update'
      }
      getObj(data.id).then(response => {
        this.form = response.data
        this.obj=this.form
         //this.$message.success('搜索数据'+ JSON.stringify(this.form));
      })
      this.currentId = data.id
      this.showElement = true
    },


    handleNodeClick (data) {
      this.parentForm = Object.assign({}, findParent(this.menuAll, data.id));
      this.formGrade = true;
      this.formStatus = "";
      this.obj = data;
      this.form = data;
    },
    /**
     * 新增菜单界面
     */
    handleAdd() {
      this.resetForm();
      // this.form = {};
      this.formEdit = false
      this.formStatus = 'create'
    },
    /**
     * 新增菜单
     */
    create(formName) {
      this.$refs[formName].validate((valid) => {
          if (valid) {
            addObj(this.form).then(() => {
              this.getList()
              this.$notify({
                title: '成功',
                message: '创建成功',
                type: 'success',
                duration: 2000
              })
            })
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      
    },
   
    /**
     * 取消按钮
     */
    onCancel() {
        this.formEdit = true
        this.formStatus = ''
    },
    /**
     * 修改按钮
     */
    handleEdit () {
      if (validatenull(this.obj)) {
        this.$message({
          showClose: true,
          message: "请选择菜单",
          type: "warning"
        });
        return false;
      }
      this.form = Object.assign({}, this.obj);
      this.formEdit = false
      this.formStatus = 'update'
    },
    /**
     * 修改菜单
     */
     update() {
      
        putObj(this.form).then(() => {
          this.getList()
          this.$notify({
            title: '成功',
            message: '更新成功',
            type: 'success',
            duration: 2000
          })
        })
      },
    /* handlerEdit() {
        if (this.form.menuId) {
          this.formEdit = false
          this.formStatus = 'update'
        }
      }, */
    /**
     * 删除按钮
     */
    handleDel () {
       //this.$message.success('搜索数据'+ JSON.stringify(this.form.menuName));
        if (validatenull(this.obj)) {
        this.$message({
          showClose: true,
          message: "请选择对应删除菜单",
          type: "warning"
        });
        return false;
      }
      this.$confirm(`是否确认删除序号为 ${this.form.menuName}
                     （如有子菜单/按钮,也将删除）`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
         delObj(this.currentId).then(()=>{
            this.getList()
            this.resetForm()
            this.onCancel()
            this.$notify({
              title: '成功',
              message: '删除成功',
              type: 'success',
              duration: 2000
            })
         }).catch(() => { 
            this.$notify({
              title: '失败',
              message: '删除失败',
              type: 'error',
              duration: 2000
            })
        });
        }).catch(() => { 
           this.$message({
            type: 'info',
            message: '已取消删除'
          });  
        });
        
    },
    handleSubmit () { },

    /**
     * 清空表单数据
     */
    resetForm() {
      this.form = {
        permission: undefined,
        menuName: undefined,
        menuId: undefined,
        parentId: this.currentId,
        url: undefined,
        icon: undefined,
        sort: undefined,
        component: undefined,
        type: undefined,
        method: undefined,
        path: undefined
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.menu-container {
  padding: 0 20px;
}
.menu-header {
  padding: 8px 0;
}
</style>
