<template>
  <div>
    <basic-container>
      <avue-crud :option="tableOption"
                 :data="tableData"
                 :table-loading="tableLoading"
                 :page="page"
                 ref="crud"
                 @row-save="handleSave"
                 @row-update="handleUpdate"
                 @row-del="handleDel"
                 @current-change="currentChange"
                 @size-change="sizeChange"
                 @search-change="searchChange"
                 @refresh-change="refreshChange">
        <template slot-scope="scope"
                  slot="menu">
          <el-button icon="el-icon-check"
                     size="small"
                     type="text"
                     @click="handleGrade(scope.row,scope.$index)">权限</el-button>
        </template>
      </avue-crud>
    <!--   <el-dialog title="菜单"
                 :visible.sync="grade.box"
                 width="40%">
        <el-tree :data="menuAll"
                 :default-checked-keys="grade.check"
                 :default-expanded-keys="grade.check"
                 show-checkbox
                 node-key="id"
                 @check-change="handleGradeCheckChange">
        </el-tree>
        <span slot="footer"
              class="dialog-footer">
          <el-button type="primary"
                     @click="handleGradeUpdate">更新</el-button>
        </span>
      </el-dialog> -->

      <el-dialog title="菜单" :visible.sync="dialogPermissionVisible">
      <el-tree class="filter-tree" :data="treeData" :default-checked-keys="checkedKeys" :check-strictly="false" node-key="id" highlight-current :props="defaultProps" show-checkbox ref="menuTree" :filter-node-method="filterNode" default-expand-all>
      </el-tree>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="updatePermession(roleId, roleCode)">更 新</el-button>
      </div>
    </el-dialog>
    </basic-container>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { getRoleData,addObj,putObj,delObj,fetchRoleTree,permissionUpd} from '@/api/role'
import { fetchTree } from '@/api/menu'
import { roleOption } from "@/const/admin/adminTabelOption.js";
export default {
  name: "role",
  components: {},
  data () {
    return {
      tableOption: {}, //表格设置属性
      tableData: [], //表格的数据
      tablePage: 1,
      tableLoading: false,
      tabelObj: {},
      page: {
        total: 0, //总页数
        currentPage: 1, //当前页数
        pageSize: 10 //每页显示多少条
      },
      grade: {
        box: false,
        check: []
      },
      roleName:"",
      treeData: [],
      treeDeptData: [],
      checkedKeys: [],
      menuIds: '',
      dialogPermissionVisible: false,
      roleId: undefined,
      roleCode: undefined,
      defaultProps: {
        children: 'children',
        label: 'name'
      },
    };
  },
  created () {
    //初始化数据格式
    this.tableOption = roleOption;
    this.handleList();
  },
  watch: {},
  mounted () { },
  computed: {
    ...mapGetters(["permission", "menuAll"])
  },
  props: [],
  methods: {
    /**
     * @title 权限更新
     *
     **/
    handleGradeUpdate () {
      this.tabelObj.check = [].concat(this.grade.check);
      this.tabelObj = {};
      this.grade.check = [];
      this.grade.box = false;
    },
    /**
     * @title 权限选择
     *
     **/
    handleGradeCheckChange (data, checked) {
      if (checked) {
        this.grade.check.push(data.id);
      } else {
        this.grade.check.splice(this.grade.check.indexOf(data.id), 1);
      }
    },
    /**
     * @title 打开权限
     */
    handleGrade (row) {

      fetchRoleTree(row.roleCode)
        .then(response => {
          this.checkedKeys = response.data
         
          return fetchTree()
        })
        .then(response => {
          this.treeData = response.data
          this.checkedKeys = this.resolveAllLeafNodeId(this.treeData, this.checkedKeys, [])
          //this.dialogStatus = 'permission'
          this.dialogPermissionVisible = true
          this.roleId = row.roleId
          this.roleCode = row.roleCode
        })


    /*   this.$store.dispatch("GetMenuAll").then(() => {
        this.grade.box = true;
        this.tabelObj = row;
        this.grade.check = this.tabelObj.check;
      }); */
    },

    filterNode(value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    /**
     * 解析出所有的叶子节点id
     * @param json 待解析的json串
     * @param idArr 原始节点数组
     * @param temp 临时存放节点id的数组
     * @return 叶子节点id数组
     */
    resolveAllLeafNodeId(json, idArr, temp) {
      for (let i = 0; i < json.length; i++) {
        const item = json[i]
        // 存在子节点，递归遍历;不存在子节点，将json的id添加到临时数组中
        if (item.children && item.children.length !== 0) {
          this.resolveAllLeafNodeId(item.children, idArr, temp)
        } else {
          temp.push(idArr.filter(id => id === item.id))
        }
      }
      return temp
    },

    /**
     * 修改角色权限
     * @param roleId 
     * @param roleCode 
     * @return 权限集合
     */
  updatePermession(roleId, roleCode) {
      this.menuIds = ''
      this.menuIds = this.$refs.menuTree.getCheckedKeys().join(',').concat(',').concat(this.$refs.menuTree.getHalfCheckedKeys().join(','))
      if(this.menuIds===','){
        this.menuIds = ''
      }
      permissionUpd(roleId, this.menuIds).then(() => {
        this.dialogPermissionVisible = false
        fetchTree()
          .then(response => {
            this.treeData = response.data
            return fetchRoleTree(roleCode)
          })
          .then(response => {
            this.checkedKeys = response.data
            this.$notify({
              title: '成功',
              message: '更新权限成功',
              type: 'success',
              duration: 2000
            })
          })
      })
    },




  
    /**
     * @title 打开新增窗口
     * @detail 调用crud的handleadd方法即可
     *
     **/
    handleAdd () {
      this.$refs.crud.rowAdd();
    },
    /**
     * @title 获取数据
     * @detail 赋值为tableData表格即可
     *
     **/
    handleList () {
      this.tableLoading = true;
      getRoleData({ currentPage : `${this.page.currentPage}`, pageSize:`${this.page.pageSize}`,roleName:`${this.roleName}` })
        .then(res => {
          const data = res.data;
          setTimeout(() => {
            this.tableData = data.records;
            this.page = {
              total: data.total,
              pageSize: data.size,
              currentPage: data.current
            };
            this.tableLoading = false;
          }, 1000);
        });
    },
    currentChange(val) {
      //alert(val)
      this.page.currentPage = val
      this.handleList()
    },
    sizeChange(val) {
      this.page.pageSize = val
      this.handleList()
    },

     /**
     * 根据角色名查询
     */
    searchChange(params){
      this.page.currentPage=1
      this.roleName=params.roleName
      this.handleList()
    },
    /**
     * 刷新
     */
    refreshChange({page,searchForm}){
      this.roleName=""
      this.handleList()
     },
    /**
     * @title 数据添加
     * @param row 为当前的数据
     * @param done 为表单关闭函数
     *
     **/
    handleSave (row, done) {
       //this.$message.success('搜索数据'+ JSON.stringify(row));
      addObj(row).then(res=>{
        this.tableData.push(row);
        this.$notify({
          title: '成功',
          message: '添加成功',
          type: 'success',
          duration: 2000
        })
        this.handleList();
        done();
      })
      
      
      
    },
    /**
     * @title 数据删除
     * @param row 为当前的数据
     * @param index 为当前更新数据的行数
     *
     **/
    handleDel (row, index) {
      this.$confirm(`是否确认删除序号为 ${row.roleName} `, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(()=>{
        delObj(row.roleId).then(() => {
          this.tableData.splice(index, 1);
           this.$notify({
              showClose: true,
              message: "删除成功",
              type: "success",
              duration: 2000
            });
        })
        .catch(() => { 
           this.$notify({
              title: "失败",
              message: "删除失败",
              type: "error",
              duration: 2000
            });
        });
      }).catch(() => { 
           this.$message({
              type: 'info',
              message: '已取消删除'
            });
        });
    },
    /**
     * @title 数据更新
     * @param row 为当前的数据
     * @param index 为当前更新数据的行数
     * @param done 为表单关闭函数
     *
     **/
    handleUpdate (row, index, done) {
      this.$message.success('搜索数据'+ JSON.stringify(row));
      putObj(row).then(res=>{
        this.tableData.splice(index, 1, row);
      /*   this.$message({
          showClose: true,
          message: "修改成功",
          type: "success"
        }); */
         this.$notify({
          title: '成功',
          message: '修改成功',
          type: 'success',
          duration: 2000
        })
      })
      this.handleList();
      done();
    }
  }
};
</script>

<style lang="scss" scoped>
.table-container {
  padding: 8px 10px;
}
</style>
