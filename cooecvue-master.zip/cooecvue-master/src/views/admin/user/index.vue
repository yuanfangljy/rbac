<template>
  <div>
    <basic-container>
      <avue-crud :option="tableOption"
                 :data="tableData"
                 :table-loading="tableLoading"
                 :page="page"
                 ref="crud"
                 @row-save="handleSave"
                 @row-update="handleUpdate"
                 @row-del="handleDel"
                 @current-change="currentChange"
                 @size-change="sizeChange"
                 @search-change="searchChange"
                 @refresh-change="refreshChange"
                 >
        <template slot-scope="scope" slot="userName">
          <el-tag type="success">{{scope.row.userName}}</el-tag>
        </template>          
        <template slot-scope="scope" slot="roles">
           <el-tag>{{ scope.row.roles }}</el-tag>
            <!-- <el-tag v-for="value in scope.row.roleList" :key="value.roleId">
               {{ value.roleName }}
            </el-tag> -->
          <!-- <el-tag :type="scope.row.role!=''?'success':'danger'">123</el-tag> -->
         <!--  <el-tag :type="scope.row.role!=''?'success':'danger'">{{scope.row.role}}</el-tag> -->
        </template>   
        <template slot-scope="scope" slot="delFlag">
          {{scope.row.delFlag}}
          <!-- <el-tag :type="scope.row.del=='1'?'success':'danger'">{{scope.row.delFlag.del}}</el-tag> -->
        </template>
         <template slot-scope="scope" slot="menu">
          <el-button type="text"
                          icon="el-icon-check"
                          size="small"
                          plain
                          @click.stop="handleEdit(scope.row,scope.index)">编辑</el-button>
        </template>
      </avue-crud>
     
    </basic-container>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { getUserData,delObj,putObj,addObj } from '@/api/user'
import { getLabel } from '@/api/dict'
import { userOption } from "@/const/admin/adminTabelOption.js";
export default {
  name: "user",
  components: {},
  data () {
    return {
      tableOption: userOption, //表格设置属性
      tableData: [], //表格的数据
      tableLoading: false,
      page: {
        total: 0, //总页数
        currentPage: 1, //当前页数
        pageSize: 10 //每页显示多少条
      },
      userName:"",
    };
  },
  created () {
    this.handleList();
  },
  filters: {
      
    /*   findByvalue(value,type) {
        let data;
          getLabel(value,type).then(res => {
            data= res.data;
          })
          return data;
      } */
  },
  watch: {},
  mounted () { },
  computed: {
    ...mapGetters(["permission", "menuAll"]),
    // 控制显示的内容
  

   /*  (value,type) {
      getLabel(value,type).then(res => {
        alert(res.data)
        return res.data;
      })
      
    } */
  },
  props: [],
  methods: {
     handleEdit (row, index) {
        this.$message.success('搜索数据'+ JSON.stringify(row));
        this.$refs.crud.rowEdit(row, index);
      }, 
    /**
     * @title 获取字典
     * @detail 调用crud的findByvalue方法即可
     *
     **/
    findByvalue (dic, value) {
      return this.getname(dic, value);
    }, 

    getname(value,type){
       getLabel(value,type).then(res => {
        //alert(res.data)
        return res.data;
      })
    },
    /**
     * @title 打开新增窗口
     * @detail 调用crud的handleadd方法即可
     *
     **/
    handleAdd () {
      this.$refs.crud.rowAdd();
    },
    /**
     * @title 获取数据
     * @detail 赋值为tableData表格即可
     *
     **/
    handleList () {
      this.tableLoading = true;
      getUserData({currentPage : `${this.page.currentPage}`, pageSize:`${this.page.pageSize}`,userName:`${this.userName}`})
        .then(res => {
          const data = res.data;
        // /*  for (const role in data) {
        //   this.$message.success('搜索数据'+ JSON.stringify(data[role].roleList.roleName));
        // } */
        //console.log(JSON.stringify(data))
         
          setTimeout(() => {
            this.tableData = data.records;
              this.page = {
              total: data.total,
              pageSize: data.size,
              currentPage: data.current
            };  
            this.tableLoading = false;
          }, 1000);
        });
    },
    /*  currentChange(val) {
      console.log(val)
      this.handleList()
    },  */
    currentChange(val) {
      //alert(val)
      this.page.currentPage = val
      this.handleList()
    },
    sizeChange(val) {
      this.page.pageSize = val
      this.handleList()
    },
    /**
     * 根据用户名查询
     */
    searchChange(params){
      this.page.currentPage=1
      this.userName=params.userName
      this.handleList()
    },
    /**
     * 刷新
     */
    refreshChange({page,searchForm}){
      this.userName=""
      this.handleList()
     },
    /**
     * @title 数据添加
     * @param row 为当前的数据
     * @param done 为表单关闭函数
     *
     **/
    handleSave (row, done) {
      addObj(row).then(res=>{
        this.tableData.push(row);
          this.$notify({
            title: '成功',
            message: '添加成功',
            type: 'success',
            duration: 2000
          })
         this.handleList()
          done();
      })
     
     
    },
    /**
     * @title 数据删除
     * @param row 为当前的数据
     * @param index 为当前更新数据的行数
     *
     **/
    handleDel (row, index) {
      this.$confirm(`是否确认删除用户名为 ${row.userName}`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          delObj(`${row.userId}`).then(res => {
            this.tableData.splice(index, 1);
              //this.handleList()
            this.$notify({
              title: '成功',
              message: '删除成功',
              type: 'success',
              duration: 2000
            })
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });  
         });
    },
    /**
     * @title 数据更新
     * @param row 为当前的数据
     * @param index 为当前更新数据的行数
     * @param done 为表单关闭函数
     *
     **/
    handleUpdate (row, index, done) {
       //this.$message.success('搜索数据'+ JSON.stringify(row));
     putObj(row).then(data => {
        this.tableData.splice(index, 1, Object.assign({}, row))
         this.$notify({
            title: '成功',
            message: '修改成功',
            type: 'success',
            duration: 2000
        })
        done()
        this.handleList()
      })

    /*   this.tableData.splice(index, 1, row);
      this.$message({
        showClose: true,
        message: "修改成功",
        type: "success"
      });
      done(); */
    }

  }
};
</script>

<style lang="scss" scoped>
.table-container {
  padding: 8px 10px;
}
</style>
