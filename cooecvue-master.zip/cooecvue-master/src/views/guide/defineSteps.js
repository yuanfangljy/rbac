const steps = [{
    element: '.guide-container',
    popover: {
        title: '介绍的标题',
        description: '介绍的内容',
        position: 'bottom'
    }
}]

export default steps