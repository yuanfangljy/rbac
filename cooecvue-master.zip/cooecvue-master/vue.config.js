// 基础路径 注意发布之前要先修改这里
let baseUrl = './'
//'http://192.168.3.107:8889'   'http://192.168.30.203:8889'
let target = 'http://192.168.3.156:8889'
module.exports = {
    baseUrl:baseUrl,//根路径
    outputDir:'/dist',//build 构建输出目录
    assetsDir:'assets',//静态资源目录（js，css,img,fonts）
    lintOnSave:false,//是否开启eslint保存检测，有效值 true || false || 'error'


    //配置转发代理
    devServer: {
        open:false,//浏览器自动打开页面
        //host:'localhost',
        port:8777,
        https:false,
        hotOnly:false,//加入模块的时候，热加载
       // publicPath: baseUrl ,// 和 baseUrl 保持一致
      proxy:{
            '/auth':{
                target:target,//后端接口
                ws:true,
                changOrigin:true,//是否跨域
                pathRewrite:{
                    '^/auth':''//给当前后端接口另取别名
                }
            }, 
            '/admin':{
                target:target,//后端接口
                ws:true,
                changOrigin:true,//是否跨域
                pathRewrite:{
                    '^/admin':''//给当前后端接口另取别名
                }
            }
        } 
    },


    productionSourceMap: false,
    chainWebpack: (config) => {
        //忽略的打包文件
        config.externals({
            'vue': 'Vue',
            'vue-router': 'VueRouter',
            'vuex': 'Vuex',
            'axios': 'axios',
            'element-ui': 'ELEMENT',
        })
        const entry = config.entry('app')
        entry
            .add('babel-polyfill')
            .end()
        entry
            .add('classlist-polyfill')
            .end()
        entry
            .add('@/mock')
            .end()
    },
    transpileDependencies: ['avue-plugin-transfer', 'avue-plugin-ueditor'],
    
    
}